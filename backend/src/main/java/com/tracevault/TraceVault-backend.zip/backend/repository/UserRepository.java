package com.tracevault.backend.repository;

import com.tracevault.backend.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;


public interface UserRepository extends JpaRepository<User, UUID> {
    Optional<User> findByEmail(String email);

    boolean existByEmail(String email);

    Optional<User> findByAccountCode(String accountCode);
    
}
